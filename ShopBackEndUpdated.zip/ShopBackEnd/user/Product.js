const mongoose = require('mongoose');
const ProductSchema = new mongoose.Schema({
  ProductName: String,
  Category: String,
  Price: Number,
  Discount: Number,
  Description: String,
  ProductImage: String,
  CreatedOn: Date,
  TopProduct:Boolean
}, { versionKey: false });

module.exports = mongoose.model('Product', ProductSchema, 'Product')