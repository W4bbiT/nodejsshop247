const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
  firstname: String,
  lastname: String,
  email: String,
  password: String,
  profileImage: String,
  role: String,
  address: {
    streetAddress: String,
    city: String,
    state: String,
    zipcode: String
  },
  cart: [{
    productId: String,
    quantity: Number
  }],
  order:[{
    user: String,
    orderPlacedOn: Date,
    isDelivered: Boolean,
    orderDeliveredOn:Date,
    items:[{
      itemId: String,
      quantity: Number
    }]
  }]


}, { versionKey: false });

module.exports = mongoose.model('User', UserSchema, 'user')