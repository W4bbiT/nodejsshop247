const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const LocalStorage = require('node-localstorage').LocalStorage;
const config = require('../config.js');
const jwt = require('jsonwebtoken');
localStorage = new LocalStorage('./scratch');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());
const User = require('./User');
const Product = require('./Product');


// RETURNS ALL THE USERS IN THE DATABASE
router.get('/', function (req, res) {
    User.find({}, (err, users) => {
        if (err) return res.status(500).send("There was a problem finding the users.");
        res.status(200).send(users);
    });
});

// GETS A SINGLE USER FROM THE DATABASE
router.get('/profile', (req, res) => {
    var token = localStorage.getItem('authtoken')

    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };
        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }
            res.render('profile', { user })
            //res.send(user)
        });
    });
});

router.patch('/profile/image', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };
        User.findByIdAndUpdate(decoded.id, {
            $set: {
                profileImage: req.body.profileImage,
            }
        }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }
            res.send(user.profileImage)
            console.log(user)

        });
    });
});
router.patch('/profile/address', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };

        User.findByIdAndUpdate(decoded.id, {
            $set: {
                address: {
                    streetAddress: req.body.streetAddress,
                    city: req.body.city,
                    state: req.body.state,
                    zipcode: req.body.zipcode
                }
            }
        }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }

            res.send(user.address)
            console.log(user)

        });




    });
});

// GETS A SINGLE USER FROM THE DATABASE

router.get('/homepage/banner', (req, res) => {
    Product.find({}, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    }).sort({ productCreatedOn: -1 }).limit(3)
})

router.get('/homepage/categories', (req, res) => {
    Product.find({}, { productCategory: 1, _id: 0 }, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    }).limit(3)
})

router.get('/homepage/products', (req, res) => {
    Product.find({}, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    }).limit(8)
})

router.get('/products', (req, res) => {
    Product.find({}, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    })
})

router.get('/products/:PRODUCT_ID', (req, res) => {
    const ID = req.params['PRODUCT_ID']
    Product.find({ _id: ID }, (err, result) => {
        if (err) {
            res.send(err)
        }
        res.send(result)
    })
})

router.post('/checkout', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };
        User.findById(decoded.id, { password: 0 }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }
       

            User.findByIdAndUpdate(decoded.id, {
                $set: {
                    order: [{
                        user: user._id,
                        orderPlacedOn: Date.now(),
                        isDelivered: false,
                        orderDeliveredOn: Date.now(),
                        items: [{
                            productId: req.body.productId,
                            quantity:req.body.quantity
                        }]
                    }]
                }

            }, (err, user) => {
                if (err) { res.redirect('/') }
                if (!user) { res.redirect('/') }

                console.log(decoded.id)
                res.send(user)
                console.log(user)
            });
            //res.send(user)
        });
    });
});

router.post('/cart', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };

        User.findByIdAndUpdate(decoded.id, {
            $push: {
                cart: [{
                    productId: req.body.productId,
                    quantity: req.body.quantity
                }]
            }
        }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) {
                User.create({
                    firstname: req.body.firstname,
                    lastname: req.body.lastname,
                    email: req.body.email,
                    password: hashedPassword

                }, (err, buser) => {
                    if (err) return res.status(500).send("There was a problem registering the user.")
                    // create a token
                    var token = jwt.sign({ id: buser._id }, config.secret, {
                        expiresIn: 86400 // expires in 24 hours
                    });
                    const string = encodeURIComponent('Success Fully Register Please Login');
                    return res.status(200).send({ auth: true, token: token })
                    user: buser
                });
            }

            res.send(user.cart)
            console.log(user)
        });

    });
});

router.get('/order', (req, res) => {
    var token = localStorage.getItem('authtoken')
    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            res.redirect('/')
        };

        User.find(decoded.id, {
            $push: {
                order: [{
                    productId: req.body.productId,
                    quantity: req.body.quantity
                }]
            }
        }, (err, user) => {
            if (err) { res.redirect('/') }
            if (!user) { res.redirect('/') }

            res.send(user.order)
            console.log(user)
        });

    });
});


router.get('/users/logout', (req, res) => {
    localStorage.removeItem('authtoken');
    res.redirect('/');
})

router.post('/admin/products', (req, res) => {
    var token = localStorage.getItem('authtoken')

    console.log("token>>>", token)
    if (!token) {
        res.redirect('/')
    }
    jwt.verify(token, config.secret, function (err, decoded) {
        if (err) {
            res.redirect('/')
        };

        Product.create({
            ProductName: req.body.ProductName,
            Category: req.body.Category,
            Price: req.body.Price,
            Discount: req.body.Discount,
            ProductImage: req.body.ProductImage,
            Description: req.body.Description,
            CreatedOn: Date.now(),
            TopProduct: req.body.TopProduct

        }, (err, product) => {
            if (err) { res.redirect('/') }
            res.send(product)
            console.log(product)
        });
    });
});



module.exports = router;